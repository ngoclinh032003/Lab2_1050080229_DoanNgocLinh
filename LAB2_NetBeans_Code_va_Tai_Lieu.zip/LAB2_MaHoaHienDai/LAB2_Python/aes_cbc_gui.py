import base64, secrets, sys, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

def new_key(): return base64.b64encode(secrets.token_bytes(32)).decode()
def new_iv(): return base64.b64encode(secrets.token_bytes(16)).decode()
def check(kb, ib):
    try: k=base64.b64decode(kb,validate=True); iv=base64.b64decode(ib,validate=True)
    except Exception: raise ValueError("Key/IV phải là Base64 hợp lệ.")
    if len(k)!=32 or len(iv)!=16: raise ValueError("Key phải 32 byte và IV phải 16 byte.")
    return k,iv
def encrypt_text(text,kb,ib):
    k,iv=check(kb,ib); pad=padding.PKCS7(128).padder()
    data=pad.update(text.encode("utf-8"))+pad.finalize()
    c=Cipher(algorithms.AES(k),modes.CBC(iv)).encryptor()
    return base64.b64encode(c.update(data)+c.finalize()).decode()
def decrypt_text(ct,kb,ib):
    k,iv=check(kb,ib)
    try: data=base64.b64decode(ct.strip(),validate=True)
    except Exception: raise ValueError("Ciphertext phải là Base64.")
    if not data or len(data)%16: raise ValueError("Độ dài bản mã phải là bội số 16 byte.")
    c=Cipher(algorithms.AES(k),modes.CBC(iv)).decryptor(); padded=c.update(data)+c.finalize()
    try:
        u=padding.PKCS7(128).unpadder(); plain=u.update(padded)+u.finalize()
        return plain.decode("utf-8")
    except Exception: raise ValueError("Giải mã thất bại: sai Key/IV hoặc bản mã bị sửa.")
class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title("AES-CBC Python - LAB 2"); self.resizable(False,False)
        f=ttk.Frame(self,padding=12); f.grid()
        ttk.Label(f,text="BÀI NÂNG CAO 02 - AES-256-CBC",font=("Segoe UI",14,"bold")).grid(row=0,column=0,columnspan=3,sticky="w")
        ttk.Label(f,text="Plaintext").grid(row=1,column=0,sticky="nw")
        self.pl=tk.Text(f,width=65,height=5); self.pl.grid(row=1,column=1,columnspan=2)
        self.key=tk.StringVar(); self.iv=tk.StringVar()
        ttk.Label(f,text="Key Base64").grid(row=2,column=0); ttk.Entry(f,textvariable=self.key,width=58).grid(row=2,column=1)
        ttk.Button(f,text="Generate Key",command=lambda:self.key.set(new_key())).grid(row=2,column=2)
        ttk.Label(f,text="IV Base64").grid(row=3,column=0); ttk.Entry(f,textvariable=self.iv,width=58).grid(row=3,column=1)
        ttk.Button(f,text="Generate IV",command=lambda:self.iv.set(new_iv())).grid(row=3,column=2)
        ttk.Label(f,text="Ciphertext").grid(row=4,column=0,sticky="nw")
        self.ct=tk.Text(f,width=65,height=5); self.ct.grid(row=4,column=1,columnspan=2)
        b=ttk.Frame(f); b.grid(row=5,column=1,columnspan=2,sticky="w")
        for label,fn in [("Encrypt",self.enc),("Decrypt",self.dec),("Save File",self.save),("Open File",self.open)]: ttk.Button(b,text=label,command=fn).pack(side="left",padx=3)
        self.status=tk.StringVar(value="Generate Key và Generate IV trước."); ttk.Label(f,textvariable=self.status).grid(row=6,column=1,columnspan=2,sticky="w")
    def get(self,w): return w.get("1.0","end-1c")
    def put(self,w,s): w.delete("1.0","end"); w.insert("1.0",s)
    def enc(self):
        try:self.put(self.ct,encrypt_text(self.get(self.pl),self.key.get(),self.iv.get()));self.status.set("Đã mã hóa AES-CBC.")
        except Exception as e:messagebox.showerror("Lỗi",str(e))
    def dec(self):
        try:self.put(self.pl,decrypt_text(self.get(self.ct),self.key.get(),self.iv.get()));self.status.set("Đã giải mã AES-CBC.")
        except Exception as e:messagebox.showerror("Lỗi",str(e))
    def save(self):
        path=filedialog.asksaveasfilename(defaultextension=".txt",initialfile="aes_cbc_ciphertext.txt")
        if path:
            with open(path,"w",encoding="utf-8") as f:f.write("IV="+self.iv.get()+"\n"+self.get(self.ct)+"\n")
            self.status.set("Đã lưu "+path)
    def open(self):
        path=filedialog.askopenfilename(filetypes=[("Text","*.txt")])
        if path:
            with open(path,encoding="utf-8") as f: lines=f.read().strip().split("\n",1)
            if len(lines)!=2 or not lines[0].startswith("IV="):messagebox.showerror("Lỗi","Tệp phải có dòng IV=... và dòng bản mã.");return
            self.iv.set(lines[0][3:]);self.put(self.ct,lines[1]);self.status.set("Đã mở tệp; nhập đúng Key rồi Decrypt.")
def self_test():
    k,iv=new_key(),new_iv(); long="Văn bản tiếng Việt dài. "*200
    for s in ["Xin chào AES-CBC","", "1234567890123456",long]:
        assert decrypt_text(encrypt_text(s,k,iv),k,iv)==s
    print("SELF-TEST OK")
if __name__=="__main__":
    if "--self-test" in sys.argv:self_test()
    else:App().mainloop()
