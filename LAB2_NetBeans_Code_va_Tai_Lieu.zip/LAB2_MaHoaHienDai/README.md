# LAB 2 - Mã hóa đối xứng hiện đại

## Công nghệ
- JDK 17 hoặc 21, Apache NetBeans, Maven
- SQL Server Express + SSMS (TCP/IP cổng 14333)
- Python 3.10+, thư viện `cryptography`

## Chạy Java
1. Mở thư mục project trong NetBeans (Open Project).
2. Clean and Build.
3. Run Project (F6), lớp chính `week_02.frm_Menu`.
4. Chọn tab thuật toán để thử Encrypt/Decrypt.
5. Tab SQL / Lịch sử để cấu hình SQL Server và xem lịch sử.

## SQL Server
1. Chạy `SQL/01_Tao_CSDL.sql` bằng tài khoản quản trị.
2. Chạy `SQL/02_Tao_Tai_Khoan_SQL.sql`.
3. Đảm bảo SQL Server Express bật TCP/IP, port 14333, Mixed Mode và service đã restart.
4. Trong chương trình nhập server `127.0.0.1`, port `14333`, database `LAB2_MaHoaHienDai`, user `lab2_user`, mật khẩu lab đã cấu hình trên máy cá nhân.
5. Không đưa mật khẩu thật vào GitHub.

## Chạy Python AES-CBC
```bat
py -m pip install cryptography
cd /d C:\BaoMat\LAB2_MaHoaHienDai\LAB2_Python
py aes_cbc_gui.py --self-test
py aes_cbc_gui.py
```

## Kiểm thử nhanh
- DES: plaintext `Xin chào Lab 2 - Mã hóa hiện đại!`, key `12345678`.
- TripleDES: key `123456789012345678901234` (24 byte ASCII).
- RC4: plaintext `Plaintext`, key `Key`; ciphertext HEX mong đợi `BBF316E8D940AF0AD3`.
- Twofish: bấm Generate IV, giữ đúng IV để giải mã.
- AES-CTR: Generate Key và Generate Nonce; không tái sử dụng cặp key/nonce.
- AES-GCM: đăng ký và đăng nhập trước khi mã hóa; sửa ciphertext phải khiến giải mã thất bại.

## Lưu ý về giao diện
Bản mã nguồn này tổ chức các chức năng thành các tab trong một JFrame `frm_Menu` để dễ chạy thử và bảo trì. Tài liệu LAB gốc mô tả các JFrame Form riêng được tạo bằng NetBeans Design; nếu giảng viên yêu cầu chính xác từng form `.form`, hãy tạo các JFrame Form riêng theo bảng điều khiển ở PDF và chuyển phần xử lý từ các lớp Cipher sang sự kiện nút tương ứng.

DES, TripleDES và RC4 chỉ dùng để học, không dùng trong hệ thống thật. Với ứng dụng thật, ưu tiên AES-GCM.
