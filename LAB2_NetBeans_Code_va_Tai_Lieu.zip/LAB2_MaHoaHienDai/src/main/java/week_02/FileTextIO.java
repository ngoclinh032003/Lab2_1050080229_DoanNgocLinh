package week_02;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public final class FileTextIO {
    private FileTextIO() {}
    public static void save(JFrame parent, String content, String name) throws Exception {
        JFileChooser c=new JFileChooser(); c.setSelectedFile(new File(name));
        if(c.showSaveDialog(parent)!=JFileChooser.APPROVE_OPTION) return;
        File f=c.getSelectedFile();
        if(!f.getName().toLowerCase().endsWith(".txt")) f=new File(f.getParentFile(),f.getName()+".txt");
        Files.writeString(f.toPath(),content,StandardCharsets.UTF_8);
        JOptionPane.showMessageDialog(parent,"Đã lưu: "+f.getAbsolutePath());
    }
    public static String open(JFrame parent) throws Exception {
        JFileChooser c=new JFileChooser(); c.setFileFilter(new FileNameExtensionFilter("Text (*.txt)","txt"));
        if(c.showOpenDialog(parent)!=JFileChooser.APPROVE_OPTION) return null;
        return Files.readString(c.getSelectedFile().toPath(),StandardCharsets.UTF_8);
    }
}
