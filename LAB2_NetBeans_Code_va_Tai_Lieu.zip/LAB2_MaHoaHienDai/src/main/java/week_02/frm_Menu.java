package week_02;
import javax.swing.*;
import java.awt.*;


public class frm_Menu extends JFrame {
    @FunctionalInterface private interface CipherAction { String apply(String a, String b) throws Exception; }
    private String loggedUser=null;
    private final JTabbedPane tabs=new JTabbedPane();
    public frm_Menu(){
        setTitle("LAB 2 - Mã hóa đối xứng hiện đại");setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900,700);setLocationRelativeTo(null);
        add(tabs); tabs.addTab("2.1 DES",cipherPanel("DES","12345678",DESCipher::encrypt,DESCipher::decrypt));
        tabs.addTab("2.2 TripleDES",cipherPanel("TripleDES","123456789012345678901234",TripleDESCipher::encrypt,TripleDESCipher::decrypt));
        tabs.addTab("2.3 AES-GCM",aesPanel());
        tabs.addTab("2.4 RC4",cipherPanel("RC4","Key",RC4Cipher::encrypt,RC4Cipher::decrypt));
        tabs.addTab("2.5 Twofish",twofishPanel());
        tabs.addTab("2.6 AES-CTR",ctrPanel());
        tabs.addTab("SQL / Lịch sử",sqlPanel());
    }
    private JPanel cipherPanel(String name,String defaultKey,CipherAction enc,CipherAction dec){
        JPanel p=new JPanel(new BorderLayout(8,8));p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        JTextArea plain=new JTextArea(5,60),cipher=new JTextArea(5,60);plain.setLineWrap(true);cipher.setLineWrap(true);
        JTextField key=new JTextField(defaultKey,45);JLabel status=new JLabel("Sẵn sàng.");
        JPanel top=new JPanel(new BorderLayout());top.add(new JLabel("Key:"),BorderLayout.WEST);top.add(key);
        JPanel center=new JPanel(new GridLayout(2,1,5,5));center.add(new JScrollPane(plain));center.add(new JScrollPane(cipher));
        JPanel buttons=new JPanel();JButton e=new JButton("Encrypt"),d=new JButton("Decrypt"),s=new JButton("Save File"),o=new JButton("Open File");
        buttons.add(e);buttons.add(d);buttons.add(s);buttons.add(o);
        e.addActionListener(x->{try{String out=enc.apply(plain.getText(),key.getText());cipher.setText(out);HistoryDao.tryInsert(name,"ENCRYPT",loggedUser,plain.getText().length(),out.length());status.setText("Đã mã hóa.");}catch(Exception ex){error(ex);}});
        d.addActionListener(x->{try{String out=dec.apply(cipher.getText(),key.getText());plain.setText(out);HistoryDao.tryInsert(name,"DECRYPT",loggedUser,cipher.getText().length(),out.length());status.setText("Đã giải mã.");}catch(Exception ex){error(ex);}});
        s.addActionListener(x->{try{FileTextIO.save(this,cipher.getText(),name.toLowerCase()+"_ciphertext.txt");}catch(Exception ex){error(ex);}});
        o.addActionListener(x->{try{String v=FileTextIO.open(this);if(v!=null)cipher.setText(v);}catch(Exception ex){error(ex);}});
        JPanel bottom=new JPanel(new BorderLayout());bottom.add(buttons,BorderLayout.NORTH);bottom.add(status,BorderLayout.SOUTH);
        p.add(top,BorderLayout.NORTH);p.add(center);p.add(bottom,BorderLayout.SOUTH);return p;
    }
    private JPanel aesPanel(){
        JPanel p=new JPanel(new BorderLayout(8,8));p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        JTextField user=new JTextField("sinhvien01",18),key=new JTextField(30);JPasswordField pass=new JPasswordField(18);
        JTextArea plain=new JTextArea(4,60),cipher=new JTextArea(4,60);JTextField ticket=new JTextField(36);ticket.setEditable(false);
        JLabel status=new JLabel("Cần kết nối SQL, Register và Login.");
        JPanel auth=new JPanel(new GridLayout(3,2,5,5));auth.add(new JLabel("Username"));auth.add(user);auth.add(new JLabel("Password tài khoản"));auth.add(pass);
        JButton reg=new JButton("Register"),login=new JButton("Login");auth.add(reg);auth.add(login);
        JButton connect=new JButton("Kết nối SQL");auth.add(connect);auth.add(new JLabel("Ticket"));auth.add(ticket);
        JPanel k=new JPanel(new BorderLayout());k.add(new JLabel("Key AES: "),BorderLayout.WEST);k.add(key);
        JButton en=new JButton("Encrypt"),de=new JButton("Decrypt"),save=new JButton("Save File"),open=new JButton("Open File");
        JPanel b=new JPanel();for(JButton z:new JButton[]{en,de,save,open})b.add(z);
        JPanel body=new JPanel(new GridLayout(2,1,4,4));body.add(new JScrollPane(plain));body.add(new JScrollPane(cipher));
        connect.addActionListener(e->sqlDialog());
        reg.addActionListener(e->{try{UserDao.register(user.getText().trim(),pass.getPassword());HistoryDao.tryInsert("AES","REGISTER",user.getText(),0,0);status.setText("Đăng ký thành công.");}catch(Exception ex){error(ex);}});
        login.addActionListener(e->{try{if(UserDao.login(user.getText().trim(),pass.getPassword())){loggedUser=user.getText().trim();ticket.setText(CipherUtil.hex(CipherUtil.randomBytes(16)));HistoryDao.tryInsert("AES","LOGIN",loggedUser,0,0);status.setText("Login thành công.");}else{loggedUser=null;ticket.setText("");throw new IllegalArgumentException("Sai username hoặc mật khẩu.");}}catch(Exception ex){error(ex);}});
        en.addActionListener(e->{if(loggedUser==null){error(new Exception("Hãy Login trước khi dùng AES."));return;}try{cipher.setText(AESCipher.encrypt(plain.getText(),key.getText()));HistoryDao.tryInsert("AES","ENCRYPT",loggedUser,plain.getText().length(),cipher.getText().length());status.setText("AES-GCM Encrypt thành công.");}catch(Exception ex){error(ex);}});
        de.addActionListener(e->{if(loggedUser==null){error(new Exception("Hãy Login trước khi dùng AES."));return;}try{plain.setText(AESCipher.decrypt(cipher.getText(),key.getText()));HistoryDao.tryInsert("AES","DECRYPT",loggedUser,cipher.getText().length(),plain.getText().length());status.setText("AES-GCM Decrypt thành công.");}catch(Exception ex){error(ex);}});
        save.addActionListener(e->{try{FileTextIO.save(this,cipher.getText(),"aes_ciphertext.txt");}catch(Exception ex){error(ex);}});
        open.addActionListener(e->{try{String v=FileTextIO.open(this);if(v!=null)cipher.setText(v);}catch(Exception ex){error(ex);}});
        JPanel north=new JPanel(new BorderLayout());north.add(auth,BorderLayout.NORTH);north.add(k,BorderLayout.SOUTH);
        JPanel bottom=new JPanel(new BorderLayout());bottom.add(b,BorderLayout.NORTH);bottom.add(status,BorderLayout.SOUTH);
        p.add(north,BorderLayout.NORTH);p.add(body);p.add(bottom,BorderLayout.SOUTH);return p;
    }
    private JPanel twofishPanel(){
        JPanel p=new JPanel(new BorderLayout(6,6));p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        JTextField key=new JTextField("Twofish@Lab2",30),iv=new JTextField(36);JTextArea plain=new JTextArea(4,60),cipher=new JTextArea(4,60);JLabel st=new JLabel("Generate IV trước khi mã hóa.");
        JButton gen=new JButton("Generate IV"),en=new JButton("Encrypt"),de=new JButton("Decrypt"),save=new JButton("Save File"),open=new JButton("Open File");
        JPanel top=new JPanel(new GridLayout(2,2,5,5));top.add(new JLabel("Key"));top.add(key);top.add(new JLabel("IV HEX"));top.add(iv);
        JPanel mid=new JPanel(new GridLayout(2,1,4,4));mid.add(new JScrollPane(plain));mid.add(new JScrollPane(cipher));
        JPanel b=new JPanel();for(JButton x:new JButton[]{gen,en,de,save,open})b.add(x);
        gen.addActionListener(e->iv.setText(TwofishCipher.newIv()));
        en.addActionListener(e->{try{cipher.setText(TwofishCipher.encrypt(plain.getText(),key.getText(),iv.getText()));HistoryDao.tryInsert("Twofish","ENCRYPT",loggedUser,plain.getText().length(),cipher.getText().length());st.setText("Encrypt thành công.");}catch(Exception ex){error(ex);}});
        de.addActionListener(e->{try{plain.setText(TwofishCipher.decrypt(cipher.getText(),key.getText(),iv.getText()));HistoryDao.tryInsert("Twofish","DECRYPT",loggedUser,cipher.getText().length(),plain.getText().length());st.setText("Decrypt thành công.");}catch(Exception ex){error(ex);}});
        save.addActionListener(e->{try{FileTextIO.save(this,TwofishCipher.toFile(iv.getText(),cipher.getText()),"twofish_ciphertext.txt");}catch(Exception ex){error(ex);}});
        open.addActionListener(e->{try{String v=FileTextIO.open(this);if(v!=null){String[] a=TwofishCipher.fromFile(v);iv.setText(a[0]);cipher.setText(a[1]);}}catch(Exception ex){error(ex);}});
        JPanel bottom=new JPanel(new BorderLayout());bottom.add(b,BorderLayout.NORTH);bottom.add(st,BorderLayout.SOUTH);
        p.add(top,BorderLayout.NORTH);p.add(mid);p.add(bottom,BorderLayout.SOUTH);return p;
    }
    private JPanel ctrPanel(){
        JPanel p=new JPanel(new BorderLayout(6,6));p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        JTextField key=new JTextField(48),nonce=new JTextField(48);JTextArea plain=new JTextArea(4,60),cipher=new JTextArea(4,60);JLabel st=new JLabel("Generate Key và Nonce.");
        JButton gk=new JButton("Generate Key"),gn=new JButton("Generate Nonce"),en=new JButton("Encrypt"),de=new JButton("Decrypt"),save=new JButton("Save"),open=new JButton("Open");
        JPanel top=new JPanel(new GridLayout(2,3,5,5));top.add(new JLabel("Key Base64"));top.add(key);top.add(gk);top.add(new JLabel("Nonce Base64"));top.add(nonce);top.add(gn);
        JPanel mid=new JPanel(new GridLayout(2,1,4,4));mid.add(new JScrollPane(plain));mid.add(new JScrollPane(cipher));
        JPanel b=new JPanel();for(JButton x:new JButton[]{en,de,save,open})b.add(x);
        gk.addActionListener(e->key.setText(AESCTRCipher.newKey()));gn.addActionListener(e->nonce.setText(AESCTRCipher.newNonce()));
        en.addActionListener(e->{try{cipher.setText(AESCTRCipher.encrypt(plain.getText(),key.getText(),nonce.getText()));HistoryDao.tryInsert("AES-CTR","ENCRYPT",loggedUser,plain.getText().length(),cipher.getText().length());st.setText("AES-CTR Encrypt thành công.");}catch(Exception ex){error(ex);}});
        de.addActionListener(e->{try{plain.setText(AESCTRCipher.decrypt(cipher.getText(),key.getText(),nonce.getText()));HistoryDao.tryInsert("AES-CTR","DECRYPT",loggedUser,cipher.getText().length(),plain.getText().length());st.setText("AES-CTR Decrypt thành công.");}catch(Exception ex){error(ex);}});
        save.addActionListener(e->{try{FileTextIO.save(this,AESCTRCipher.toFile(nonce.getText(),cipher.getText()),"aes_ctr_ciphertext.txt");}catch(Exception ex){error(ex);}});
        open.addActionListener(e->{try{String v=FileTextIO.open(this);if(v!=null){String[] a=AESCTRCipher.fromFile(v);nonce.setText(a[0]);cipher.setText(a[1]);}}catch(Exception ex){error(ex);}});
        JPanel bottom=new JPanel(new BorderLayout());bottom.add(b,BorderLayout.NORTH);bottom.add(st,BorderLayout.SOUTH);
        p.add(top,BorderLayout.NORTH);p.add(mid);p.add(bottom,BorderLayout.SOUTH);return p;
    }
    private JPanel sqlPanel(){
        JPanel p=new JPanel(new BorderLayout());JButton c=new JButton("Cấu hình / Test SQL"),h=new JButton("Tải lịch sử");JTable table=new JTable();JPanel b=new JPanel();b.add(c);b.add(h);
        c.addActionListener(e->sqlDialog());h.addActionListener(e->{try{table.setModel(HistoryDao.latest());}catch(Exception ex){error(ex);}});
        p.add(b,BorderLayout.NORTH);p.add(new JScrollPane(table));return p;
    }
    private void sqlDialog(){
        JTextField server=new JTextField("127.0.0.1"),port=new JTextField("14333"),db=new JTextField("LAB2_MaHoaHienDai"),u=new JTextField("lab2_user");JPasswordField pw=new JPasswordField();
        JPanel form=new JPanel(new GridLayout(5,2,4,4));for(Object[] a:new Object[][]{{"Server",server},{"Port",port},{"Database",db},{"User",u},{"Password",pw}}){form.add(new JLabel((String)a[0]));form.add((Component)a[1]);}
        if(JOptionPane.showConfirmDialog(this,form,"Kết nối SQL Server",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
            try{DbConfig.configure(server.getText(),Integer.parseInt(port.getText()),db.getText(),u.getText(),pw.getPassword());JOptionPane.showMessageDialog(this,DbConfig.test());}
            catch(Exception ex){error(ex);}
        }
    }
    private void error(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Lỗi",JOptionPane.ERROR_MESSAGE);}
    public static void main(String[] args){SwingUtilities.invokeLater(()->new frm_Menu().setVisible(true));}
}
