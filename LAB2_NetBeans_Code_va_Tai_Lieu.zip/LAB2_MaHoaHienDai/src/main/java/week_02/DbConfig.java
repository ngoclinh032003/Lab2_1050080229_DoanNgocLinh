package week_02;
import java.sql.Connection;
import java.sql.DriverManager;
public final class DbConfig {
    private static String url,user; private static char[] password;
    private DbConfig(){}
    public static void configure(String server,int port,String database,String username,char[] pass){
        url="jdbc:sqlserver://"+server+":"+port+";databaseName="+database+";encrypt=true;trustServerCertificate=true;loginTimeout=5";
        user=username;password=pass.clone();
    }
    public static boolean ready(){return url!=null;}
    public static Connection open()throws Exception{
        if(!ready())throw new IllegalStateException("Chưa cấu hình kết nối SQL Server.");
        return DriverManager.getConnection(url,user,new String(password));
    }
    public static String test()throws Exception{try(Connection c=open()){return "Kết nối thành công: "+c.getCatalog();}}
}
