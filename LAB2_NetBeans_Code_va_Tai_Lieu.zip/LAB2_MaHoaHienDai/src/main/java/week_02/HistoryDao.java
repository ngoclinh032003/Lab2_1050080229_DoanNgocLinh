package week_02;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
public final class HistoryDao {
    private HistoryDao(){}
    public static void insert(String alg,String op,String username,int in,int out)throws Exception{
        String q="INSERT INTO dbo.crypto_history(algorithm,operation,app_username,input_length,output_length) VALUES(?,?,?,?,?)";
        try(Connection c=DbConfig.open();PreparedStatement p=c.prepareStatement(q)){
            p.setString(1,alg);p.setString(2,op);p.setString(3,username);p.setInt(4,in);p.setInt(5,out);p.executeUpdate();
        }
    }
    public static void tryInsert(String alg,String op,String u,int in,int out){
        if(!DbConfig.ready())return;try{insert(alg,op,u,in,out);}catch(Exception e){System.err.println("Không lưu được lịch sử: "+e.getMessage());}
    }
    public static DefaultTableModel latest()throws Exception{
        DefaultTableModel m=new DefaultTableModel(new String[]{"ID","Thời gian","Thuật toán","Thao tác","User","Dài vào","Dài ra"},0);
        try(Connection c=DbConfig.open();PreparedStatement p=c.prepareStatement("SELECT TOP 50 history_id,created_at,algorithm,operation,app_username,input_length,output_length FROM dbo.crypto_history ORDER BY history_id DESC");ResultSet r=p.executeQuery()){
            while(r.next())m.addRow(new Object[]{r.getLong(1),r.getTimestamp(2),r.getString(3),r.getString(4),r.getString(5),r.getInt(6),r.getInt(7)});
        }return m;
    }
}
