package week_02;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
public final class AESCTRCipher {
    private AESCTRCipher(){}
    public static String newKey(){return CipherUtil.b64(CipherUtil.randomBytes(32));}
    public static String newNonce(){return CipherUtil.b64(CipherUtil.randomBytes(12));}
    private static byte[] crypt(int mode,byte[] input,String kb,String nb)throws Exception{
        byte[] k=CipherUtil.fromB64(kb),n=CipherUtil.fromB64(nb);
        if(k.length!=32||n.length!=12)throw new IllegalArgumentException("Key phải 32 byte, Nonce phải 12 byte Base64.");
        byte[] ctr=Arrays.copyOf(n,16);ctr[15]=1;
        Cipher c=Cipher.getInstance("AES/CTR/NoPadding");
        c.init(mode,new SecretKeySpec(k,"AES"),new IvParameterSpec(ctr));return c.doFinal(input);
    }
    public static String encrypt(String p,String k,String n)throws Exception{return CipherUtil.b64(crypt(Cipher.ENCRYPT_MODE,CipherUtil.utf8(p),k,n));}
    public static String decrypt(String c,String k,String n)throws Exception{return CipherUtil.text(crypt(Cipher.DECRYPT_MODE,CipherUtil.fromB64(c),k,n));}
    public static String toFile(String n,String c){return "NONCE="+n.trim()+"\n"+c.trim()+"\n";}
    public static String[] fromFile(String s){String[] a=s.trim().split("\\R",2);if(a.length<2||!a[0].startsWith("NONCE="))throw new IllegalArgumentException("Tệp cần dòng 1 NONCE=..., dòng 2 bản mã.");return new String[]{a[0].substring(6).trim(),a[1].trim()};}
}
