package week_02;
import java.security.MessageDigest;
import java.sql.*;
public final class UserDao {
    private static final int ROUNDS=120_000;
    private UserDao(){}
    public static void register(String username,char[] password)throws Exception{
        if(!username.matches("[A-Za-z0-9_.]{3,40}"))throw new IllegalArgumentException("Username 3-40 ký tự, chỉ chữ, số, _ hoặc .");
        if(password.length<8)throw new IllegalArgumentException("Mật khẩu phải có ít nhất 8 ký tự.");
        byte[] salt=CipherUtil.randomBytes(16),hash=CipherUtil.pbkdf2(password,salt,ROUNDS,256);
        try(Connection c=DbConfig.open();PreparedStatement p=c.prepareStatement("INSERT INTO dbo.app_users(username,salt,password_hash) VALUES(?,?,?)")){
            p.setString(1,username);p.setBytes(2,salt);p.setBytes(3,hash);p.executeUpdate();
        }catch(SQLException e){if(e.getErrorCode()==2627||e.getErrorCode()==2601)throw new IllegalArgumentException("Username đã tồn tại.");throw e;}
    }
    public static boolean login(String username,char[] password)throws Exception{
        try(Connection c=DbConfig.open();PreparedStatement p=c.prepareStatement("SELECT salt,password_hash FROM dbo.app_users WHERE username=?")){
            p.setString(1,username);try(ResultSet r=p.executeQuery()){if(!r.next())return false;byte[] actual=CipherUtil.pbkdf2(password,r.getBytes(1),ROUNDS,256);return MessageDigest.isEqual(r.getBytes(2),actual);}
        }
    }
}
