package week_02;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Arrays;
public final class TripleDESCipher {
    private TripleDESCipher() {}
    private static SecretKeySpec key(String s) {
        byte[] k=CipherUtil.utf8(s);
        if(k.length!=24)throw new IllegalArgumentException("Khóa TripleDES phải đúng 24 byte (24 ký tự ASCII).");
        return new SecretKeySpec(k,"DESede");
    }
    public static String encrypt(String p,String k)throws Exception{
        byte[] iv=CipherUtil.randomBytes(8); Cipher c=Cipher.getInstance("DESede/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE,key(k),new IvParameterSpec(iv));
        return CipherUtil.b64(CipherUtil.concat(iv,c.doFinal(CipherUtil.utf8(p))));
    }
    public static String decrypt(String s,String k)throws Exception{
        byte[] a=CipherUtil.fromB64(s); if(a.length<16)throw new IllegalArgumentException("Bản mã quá ngắn.");
        Cipher c=Cipher.getInstance("DESede/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE,key(k),new IvParameterSpec(Arrays.copyOfRange(a,0,8)));
        return CipherUtil.text(c.doFinal(Arrays.copyOfRange(a,8,a.length)));
    }
}
