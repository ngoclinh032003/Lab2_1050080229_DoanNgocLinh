package week_02;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class CipherUtil {
    private static final SecureRandom RNG = new SecureRandom();
    private CipherUtil() {}
    public static byte[] utf8(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    public static String text(byte[] b) { return new String(b, StandardCharsets.UTF_8); }
    public static String b64(byte[] b) { return Base64.getEncoder().encodeToString(b); }
    public static byte[] fromB64(String s) {
        try { return Base64.getDecoder().decode(s.trim()); }
        catch (IllegalArgumentException e) { throw new IllegalArgumentException("Chuỗi Base64 không hợp lệ."); }
    }
    public static byte[] randomBytes(int n) { byte[] b = new byte[n]; RNG.nextBytes(b); return b; }
    public static String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte x : b) s.append(String.format("%02X", x & 255));
        return s.toString();
    }
    public static byte[] fromHex(String s) {
        s = s.trim();
        if ((s.length() & 1) != 0 || !s.matches("[0-9a-fA-F]*"))
            throw new IllegalArgumentException("HEX phải gồm ký tự 0-9, A-F và có độ dài chẵn.");
        byte[] b = new byte[s.length()/2];
        for (int i=0;i<b.length;i++) b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);
        return b;
    }
    public static byte[] concat(byte[] a, byte[] b) {
        byte[] o = new byte[a.length+b.length];
        System.arraycopy(a,0,o,0,a.length); System.arraycopy(b,0,o,a.length,b.length); return o;
    }
    public static void requireKey(String k) {
        if (k == null || k.isEmpty()) throw new IllegalArgumentException("Hãy nhập Key.");
    }
    public static byte[] pbkdf2(char[] password, byte[] salt, int rounds, int bits) {
        PBEKeySpec spec = new PBEKeySpec(password,salt,rounds,bits);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        catch (Exception e) { throw new IllegalStateException("Không tạo được khóa PBKDF2",e); }
        finally { spec.clearPassword(); }
    }
}
