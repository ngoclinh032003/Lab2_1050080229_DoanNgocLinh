USE LAB2_MaHoaHienDai;
GO
SELECT TOP 20 user_id,username,created_at FROM dbo.app_users ORDER BY user_id DESC;
SELECT TOP 50 * FROM dbo.crypto_history ORDER BY history_id DESC;
